# -*- encoding=utf8 -*-
__author__ = "Dell"

from airtest.core.api import *

auto_setup(__file__)

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
log = open('Web.log','w',encoding='utf-8')
# 使用Googel Chrome浏览器
from airtest_selenium.proxy import WebChrome
driver = WebChrome()
driver.maximize_window()
driver.implicitly_wait(20)
driver.get("https://you.163.com/")


# 获取结果页面 
def get_result_page():
    try:
        # 匹配结果页面的第一项
        driver.find_element_by_xpath("//span[contains(@data-reactid,'.2.0.0.3.2.0.0.') and contains(@data-reactid,'.0.4.1.0.2')]").click()
    except:
        # 失败
        log.write('查看结果页面失败，无搜索结果或出现广告\n')
    else:
        # 成功
        driver.switch_to_new_tab()
        log.write('查看结果页面成功\n')
        driver.close()
        driver.switch_to_previous_tab()
        return True

    
# 搜索记录，info为提示信息，content为搜索内容 
def search(info, content):
    log.write('搜索{}\n'.format(info))
    try:
        # 输入内容并搜索 
        driver.find_element_by_xpath("//input[@autocomplete='off']").send_keys(content)
        driver.find_element_by_xpath("//i[@data-reactid='.0.1.1.5.1.0']").click()
    except:
        log.write('搜索{}失败\n'.format(info))
        driver.get("https://you.163.com/")
    else:
        log.write('搜索{}成功\n'.format(info))
        get_result_page()
        driver.back()

def search_default():
    # 搜索默认内容，因为不确定默认内容是什么，故不检查搜索结果
    log.write('搜索默认内容\n')
    try:
        driver.find_element_by_xpath("//i[@data-reactid='.0.1.1.5.1.0']").click()
    except:
        log.write('搜索默认内容失败\n')
        driver.get("https://you.163.com/")
    else:
        log.write('搜索默认内容成功\n')
        driver.back()

def search_recommend():
    # 搜索推荐内容
    log.write('搜索推荐内容\n')
    try:
        driver.find_element_by_xpath("//input[@autocomplete='off']").click()
        driver.find_element_by_xpath("//span[@data-reactid='.0.1.1.5.2.0.3:$hot3.0']").click()
    except:
        log.write('搜索推荐内容失败\n')
        driver.get("https://you.163.com/")
    else:
        log.write('搜索推荐内容成功\n')
        # 查看结果页面 
        get_result_page()
        driver.back()

def search_history():
    # 搜索历史记录
    log.write('搜索历史记录\n')
    try:
        driver.find_element_by_xpath("//input[@autocomplete='off']").click()
        driver.find_element_by_xpath("//span[@data-reactid='.0.1.1.5.2.0.1:$history0.0']").click()
    except:
        log.write('搜索历史记录失败\n')
        driver.get("https://you.163.com/")
    else:
        log.write('搜索历史记录成功\n')
        # 查看结果页面 
        get_result_page()
        driver.back()

def search_complete():
    # 搜索联想内容
    log.write('搜索联想内容\n')
    try:
        driver.find_element_by_xpath("//input[@autocomplete='off']").send_keys("衣服")
        driver.find_element_by_xpath("//span[@data-reactid='.0.1.1.5.2.0.$autoComplete0.0']").click()
    except:
        log.write('搜索联想内容失败\n')
        driver.get("https://you.163.com/")
    else:
        log.write('搜索联想内容成功\n')
        # 查看结果页面 
        get_result_page()
        driver.back()

        
# 搜索内容测试： 
## 1. 搜索中文
search("中文","衣服")

## 2. 搜索英文，clothes，无搜索结果
search("英文","clothes")

## 3. 搜索英文，Yessing(品牌名)，有搜索结果
search("英文","Yessing")

## 4. 搜索数字，123
search("数字","123")

## 5. 搜索纯空格
search("空格"," ")

## 6. 搜索全角标点符号
search("全角标点符号","“”，。、")

## 7. 搜索半角标点符号
search("半角标点符号","“”，。、")

## 组合搜索
## 8. 搜索中文+英文
search("中文+英文","衣服 Yessing")

## 9. 搜索中文+数字
search("中文+数字","衣服 123")

## 10. 搜索英文+数字
search("英文+数字","Yessing 123")

## 11. 搜索商品+产地
search("商品+产地","衣服 中国")

## 12. 搜索商品+类型
search("商品+类型","衣服 儿童")

## 13. 搜索商品+品牌
search("商品+品牌","衣服 阿迪达斯")


# 测试基础搜索功能 
## 1. 搜索默认内容
search_default()

## 2. 搜索推荐内容 
search_recommend()

## 3. 搜索历史记录
search_history()

## 4. 搜索联想内容
search_complete()

# 搜索特殊内容
## 1. 搜索内容为空
search("空","")

## 2. 搜索内容为超长字符串
search("超长字符串","哈哈哈哈哈哈哈哈哈哈或或或或或或或或或或或或或或或或或或或或或或或或或或或或或哈哈哈哈哈啊哈哈哈哈哈哈哈啊哈哈哈哈哈哈哈哈哈哈哈哈或或或或或或或或或或或或或或或或或或或或或或或或或或或或或")

## 3. 搜索内容为特殊字符
search("特殊字符α",'α')
search("特殊字符β",'β')
search("特殊字符∂",'∂')

## 4. 搜索转义字符
search("反斜杠","\\")
search("换行","\n")
search("回车","\r")
search("制表符","\t")

## 5. sql语句
search("sql语句","select * from item where 1 = 1")

## 6. 正则表达式
search("正则表达式[0-9]*","[0-9]*")
search("正则表达式[a-z]*","[a-z]*")

# 敏感内容
search("敏感内容","色情")

log.close()
