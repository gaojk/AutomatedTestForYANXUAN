# -*- encoding=utf8 -*-
__author__ = "Dell"

from airtest.core.api import *

auto_setup(__file__)
start_app('com.netease.yanxuan')

from poco.drivers.android.uiautomation import AndroidUiautomationPoco
poco = AndroidUiautomationPoco(use_airtest_input=True, screenshot_each_action=False)
log = open('Web.log','w',encoding='utf-8')

# 切换输入法
def change_input_method_2_vivo():
    swipe(Template(r"tpl1545221773608.png", record_pos=(-0.249, -0.879), resolution=(1080.0, 1920.0)), vector=[0.0159, 0.2838])
    touch(Template(r"tpl1545221817899.png", record_pos=(-0.174, -0.106), resolution=(1080, 1920)))
    touch(Template(r"tpl1545222841355.png", record_pos=(-0.366, 0.691), resolution=(1080, 1920)))

def change_input_method_2_yosemite():
    swipe(Template(r"tpl1545221773608.png", record_pos=(-0.249, -0.879), resolution=(1080.0, 1920.0)), vector=[0.0159, 0.2838])
    touch(Template(r"tpl1545221817899.png", record_pos=(-0.174, -0.106), resolution=(1080, 1920)))
    touch(Template(r"tpl1545228542566.png", record_pos=(-0.294, 0.559), resolution=(1080, 1920)))
    poco("com.netease.yanxuan:id/tv_home_search").click()

def click_search():
    poco("com.netease.yanxuan:id/tv_home_search").click()
    touch(Template(r"tpl1545223198521.png", record_pos=(0.415, 0.469), resolution=(1080, 1920)))

def search(info,content):
    info = '搜索{}\n'.format(info)
    print(info)
    log.write(info)
    poco("com.netease.yanxuan:id/tv_home_search").click()
    change_input_method_2_yosemite()
    text(content)
    change_input_method_2_vivo()
    click_search()
    if exists(Template(r"tpl1545230992004.png", record_pos=(-0.307, -0.654), resolution=(1080, 1920))):
        print('搜索成功')
        log.write('搜索成功')
        poco("com.netease.yanxuan:id/search_bar_return").click()
    else:
        print('搜索无结果')
        log.write('搜索无结果')
        try:
            poco("com.netease.yanxuan:id/search_bar_return").click()
        except:
            try:
                poco("com.netease.yanxuan:id/nav_left_img").click()
            except:
                poco("com.netease.yanxuan:id/search_bar_cancel").click()


def search_default():
    print('搜索默认内容')
    log.write('搜索默认内容\n')
    poco("com.netease.yanxuan:id/tv_home_search").click()
    change_input_method_2_vivo()
    click_search()
    try:
        poco("com.netease.yanxuan:id/nav_left_img").click()
    except:
        try:
            poco("com.netease.yanxuan:id/search_bar_return").click()
        except:
            poco("com.netease.yanxuan:id/search_bar_cancel").click()
            
def search_recommend():
    print('搜索推荐内容')
    log.write('搜索推荐内容\n')
    poco("com.netease.yanxuan:id/tv_home_search").click()
    poco(text="羽绒服").click()
    try:
        poco("com.netease.yanxuan:id/nav_left_img").click()
    except:
        try:
            poco("com.netease.yanxuan:id/search_bar_return").click()
        except:
            poco("com.netease.yanxuan:id/search_bar_cancel").click()

def search_history():
    print('搜索历史记录')
    log.write('搜索历史记录\n')
    poco("com.netease.yanxuan:id/tv_home_search").click()
    change_input_method_2_yosemite()
    poco(text="yessing").click()
    poco(text="Yessing短款可拆卸羽绒服两件套").click()
    try:
        poco("com.netease.yanxuan:id/nav_left_img").click()
        poco("com.netease.yanxuan:id/search_bar_return").click()
    except:
        return 

def search_complete():
    print('搜索联想内容')
    log.write('搜索联想内容\n')
    poco("com.netease.yanxuan:id/tv_home_search").click()
    change_input_method_2_yosemite()
    text('衣服')
    poco(text="衣服收纳").click()
    poco(text="抽屉式透明储物柜").click()
    try:
        poco("com.netease.yanxuan:id/nav_left_img").click()
        poco("com.netease.yanxuan:id/search_bar_return").click()
    except:
        return 
    
# 搜索内容测试： 
## 1. 搜索中文
search("中文","衣服")

## 2. 搜索英文，clothes，无搜索结果
search("英文","clothes")

## 3. 搜索英文，Yessing(品牌名)，有搜索结果
search("英文","Yessing")

## 4. 搜索数字，123
search("数字","123")

## 5. 搜索纯空格
search("空格"," ")

## 6. 搜索全角标点符号
search("全角标点符号","“”，。、")

## 7. 搜索半角标点符号
search("半角标点符号","“”，。、")

## 组合搜索
## 8. 搜索中文+英文
search("中文+英文","衣服 Yessing")

## 9. 搜索中文+数字
search("中文+数字","衣服 123")

## 10. 搜索英文+数字
search("英文+数字","Yessing 123")

## 11. 搜索商品+产地
search("商品+产地","衣服 中国")

## 12. 搜索商品+类型
search("商品+类型","衣服 儿童")

## 13. 搜索商品+品牌
search("商品+品牌","衣服 阿迪达斯")

# 测试基础搜索功能 
## 1. 搜索默认内容
search_default()

## 2. 搜索推荐内容 
search_recommend()

## 3. 搜索历史记录
search_history()

## 4. 搜索联想内容
search_complete()

# 搜索特殊内容
## 1. 搜索内容为空
search("空","")

## 2. 搜索内容为超长字符串
search("超长字符串","哈哈哈哈哈哈哈哈哈哈或或或或或或或或或或或或或或或或或或或或或或或或或或或或或哈哈哈哈哈啊哈哈哈哈哈哈哈啊哈哈哈哈哈哈哈哈哈哈哈哈或或或或或或或或或或或或或或或或或或或或或或或或或或或或或")

## 3. 搜索内容为特殊字符
search("特殊字符α",'α')
search("特殊字符β",'β')
search("特殊字符∂",'∂')

## 4. 搜索转义字符
search("反斜杠","\\")
search("换行","\n")
search("回车","\r")
search("制表符","\t")

## 5. sql语句
search("sql语句","select * from item where 1 = 1")

## 6. 正则表达式
search("正则表达式[0-9]*","[0-9]*")
search("正则表达式[a-z]*","[a-z]*")

# 敏感内容
search("敏感内容","色情")

log.close()
